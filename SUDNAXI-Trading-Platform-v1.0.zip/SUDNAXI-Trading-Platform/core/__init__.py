"""
Core application modules
"""